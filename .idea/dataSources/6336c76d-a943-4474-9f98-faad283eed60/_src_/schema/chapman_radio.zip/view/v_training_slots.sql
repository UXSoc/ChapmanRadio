CREATE VIEW v_training_slots AS
  SELECT
    `chapman_radio`.`training_slots`.`trainingslot_id`           AS `trainingslot_id`,
    `chapman_radio`.`training_slots`.`trainingslot_season`       AS `trainingslot_season`,
    `chapman_radio`.`training_slots`.`trainingslot_datetime`     AS `trainingslot_datetime`,
    `chapman_radio`.`training_slots`.`trainingslot_staffid`      AS `trainingslot_staffid`,
    `chapman_radio`.`training_slots`.`trainingslot_max`          AS `trainingslot_max`,
    `chapman_radio`.`users`.`userid`                             AS `userid`,
    `chapman_radio`.`users`.`fbid`                               AS `fbid`,
    `chapman_radio`.`users`.`email`                              AS `email`,
    `chapman_radio`.`users`.`studentid`                          AS `studentid`,
    `chapman_radio`.`users`.`phone`                              AS `phone`,
    `chapman_radio`.`users`.`fname`                              AS `fname`,
    `chapman_radio`.`users`.`lname`                              AS `lname`,
    `chapman_radio`.`users`.`name`                               AS `name`,
    `chapman_radio`.`users`.`djname`                             AS `djname`,
    `chapman_radio`.`users`.`gender`                             AS `gender`,
    `chapman_radio`.`users`.`seasons`                            AS `seasons`,
    `chapman_radio`.`users`.`classclub`                          AS `classclub`,
    `chapman_radio`.`users`.`lastlogin`                          AS `lastlogin`,
    `chapman_radio`.`users`.`lastip`                             AS `lastip`,
    `chapman_radio`.`users`.`password`                           AS `password`,
    `chapman_radio`.`users`.`verifycode`                         AS `verifycode`,
    `chapman_radio`.`users`.`type`                               AS `type`,
    `chapman_radio`.`users`.`staffgroup`                         AS `staffgroup`,
    `chapman_radio`.`users`.`staffposition`                      AS `staffposition`,
    `chapman_radio`.`users`.`staffemail`                         AS `staffemail`,
    `chapman_radio`.`users`.`confirmnewsletter`                  AS `confirmnewsletter`,
    `chapman_radio`.`users`.`workshoprequired`                   AS `workshoprequired`,
    `chapman_radio`.`users`.`suspended`                          AS `suspended`,
    `chapman_radio`.`users`.`quizpassedseasons`                  AS `quizpassedseasons`,
    `chapman_radio`.`users`.`revisionkey`                        AS `revisionkey`,
    (SELECT count(0)
     FROM `chapman_radio`.`training_signups`
     WHERE (`chapman_radio`.`training_signups`.`trainingsignup_slot` =
            `chapman_radio`.`training_slots`.`trainingslot_id`)) AS `trainingslot_count`
  FROM (`chapman_radio`.`training_slots`
    JOIN `chapman_radio`.`users`
      ON ((`chapman_radio`.`training_slots`.`trainingslot_staffid` = `chapman_radio`.`users`.`userid`)));
