CREATE VIEW v_news_active AS
  SELECT
    `chapman_radio`.`news`.`news_id`       AS `news_id`,
    `chapman_radio`.`news`.`news_title`    AS `news_title`,
    `chapman_radio`.`news`.`news_body`     AS `news_body`,
    `chapman_radio`.`news`.`news_postedby` AS `news_postedby`,
    `chapman_radio`.`news`.`news_posted`   AS `news_posted`,
    `chapman_radio`.`news`.`news_expires`  AS `news_expires`
  FROM `chapman_radio`.`news`
  WHERE ((isnull(`chapman_radio`.`news`.`news_posted`) OR (`chapman_radio`.`news`.`news_posted` < now())) AND
         (isnull(`chapman_radio`.`news`.`news_expires`) OR (`chapman_radio`.`news`.`news_expires` > now())))
  ORDER BY `chapman_radio`.`news`.`news_posted` DESC;
