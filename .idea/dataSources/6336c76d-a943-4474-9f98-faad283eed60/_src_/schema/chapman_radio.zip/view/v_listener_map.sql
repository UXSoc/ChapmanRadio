CREATE VIEW v_listener_map AS
  SELECT
    max(`chapman_radio`.`listens`.`timestamp`)     AS `listen_timestamp`,
    max(`chapman_radio`.`listens`.`source`)        AS `listen_source`,
    `chapman_radio`.`geoip`.`geoip_country`        AS `geoip_country`,
    `chapman_radio`.`geoip`.`geoip_region`         AS `geoip_region`,
    `chapman_radio`.`geoip`.`geoip_city`           AS `geoip_city`,
    avg(`chapman_radio`.`geoip`.`geoip_latitude`)  AS `geoip_latitude`,
    avg(`chapman_radio`.`geoip`.`geoip_longitude`) AS `geoip_longitude`,
    count(0)                                       AS `listen_count`
  FROM (`chapman_radio`.`listens`
    JOIN `chapman_radio`.`geoip` ON ((`chapman_radio`.`geoip`.`geoip_ip` = `chapman_radio`.`listens`.`ipaddr`)))
  WHERE (`chapman_radio`.`geoip`.`geoip_city` <> '')
  GROUP BY `chapman_radio`.`geoip`.`geoip_country`, `chapman_radio`.`geoip`.`geoip_region`,
    `chapman_radio`.`geoip`.`geoip_city`;
