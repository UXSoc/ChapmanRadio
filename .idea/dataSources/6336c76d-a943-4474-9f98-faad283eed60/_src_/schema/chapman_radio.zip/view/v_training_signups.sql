CREATE VIEW v_training_signups AS
  SELECT
    `chapman_radio`.`training_signups`.`trainingsignup_id`      AS `trainingsignup_id`,
    `chapman_radio`.`training_signups`.`trainingsignup_slot`    AS `trainingsignup_slot`,
    `chapman_radio`.`training_signups`.`trainingsignup_userid`  AS `trainingsignup_userid`,
    `chapman_radio`.`training_signups`.`trainingsignup_present` AS `trainingsignup_present`,
    `chapman_radio`.`training_slots`.`trainingslot_id`          AS `trainingslot_id`,
    `chapman_radio`.`training_slots`.`trainingslot_season`      AS `trainingslot_season`,
    `chapman_radio`.`training_slots`.`trainingslot_datetime`    AS `trainingslot_datetime`,
    `chapman_radio`.`training_slots`.`trainingslot_staffid`     AS `trainingslot_staffid`,
    `chapman_radio`.`training_slots`.`trainingslot_max`         AS `trainingslot_max`
  FROM (`chapman_radio`.`training_signups`
    JOIN `chapman_radio`.`training_slots` ON ((`chapman_radio`.`training_signups`.`trainingsignup_slot` =
                                               `chapman_radio`.`training_slots`.`trainingslot_id`)));
