CREATE VIEW v_livechat AS
  SELECT
    `chapman_radio`.`livechat`.`livechatid`           AS `livechatid`,
    `chapman_radio`.`livechat`.`contactid`            AS `contactid`,
    `chapman_radio`.`livechat`.`direction`            AS `direction`,
    `chapman_radio`.`livechat`.`message`              AS `message`,
    `chapman_radio`.`livechat`.`datetime`             AS `datetime`,
    `chapman_radio`.`livechat_contacts`.`contactkey`  AS `contactkey`,
    `chapman_radio`.`livechat_contacts`.`contactname` AS `contactname`
  FROM (`chapman_radio`.`livechat`
    LEFT JOIN `chapman_radio`.`livechat_contacts`
      ON ((`chapman_radio`.`livechat`.`contactid` = `chapman_radio`.`livechat_contacts`.`contactkey`)));
