CREATE VIEW v_features_active AS
  SELECT
    `chapman_radio`.`features`.`feature_id`       AS `feature_id`,
    `chapman_radio`.`features`.`feature_type`     AS `feature_type`,
    `chapman_radio`.`features`.`feature_title`    AS `feature_title`,
    `chapman_radio`.`features`.`feature_link`     AS `feature_link`,
    `chapman_radio`.`features`.`feature_text`     AS `feature_text`,
    `chapman_radio`.`features`.`feature_priority` AS `feature_priority`,
    `chapman_radio`.`features`.`feature_active`   AS `feature_active`,
    `chapman_radio`.`features`.`feature_size`     AS `feature_size`,
    `chapman_radio`.`features`.`feature_posted`   AS `feature_posted`,
    `chapman_radio`.`features`.`feature_expires`  AS `feature_expires`,
    `chapman_radio`.`features`.`revisionkey`      AS `revisionkey`
  FROM `chapman_radio`.`features`
  WHERE ((`chapman_radio`.`features`.`feature_active` = 1) AND (isnull(`chapman_radio`.`features`.`feature_expires`) OR
                                                                (`chapman_radio`.`features`.`feature_expires` =
                                                                 '0000-00-00 00:00:00') OR
                                                                (`chapman_radio`.`features`.`feature_expires` > now()))
         AND
         (isnull(`chapman_radio`.`features`.`feature_posted`) OR (`chapman_radio`.`features`.`feature_posted` < now())))
  ORDER BY `chapman_radio`.`features`.`feature_priority` DESC;
